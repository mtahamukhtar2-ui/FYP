package com.example.fyp_app.ui.diagnose

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.fyp_app.ui.theme.AgroGreen
import com.example.fyp_app.utils.ImageProcessor
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DiagnoseScreen(
    onImageSelected: (Uri, String) -> Unit,
    onNavigateToCamera: (String) -> Unit
) {
    val context = LocalContext.current
    var selectedCrop by remember { mutableStateOf<String?>(null) }
    val crops = listOf("Tomato", "Orange", "Potato", "Corn", "Rice", "Apple")

    val scope = rememberCoroutineScope()
    var isProcessing by remember { mutableStateOf(false) }

    // --- GALLERY LOGIC ---
    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null && selectedCrop != null) {
            scope.launch {
                isProcessing = true
                try {
                    val processedUri = ImageProcessor.processLeafImage(context, uri)
                    onImageSelected(processedUri ?: uri, selectedCrop!!)
                } catch (e: Exception) {
                    Toast.makeText(context, "Error processing image", Toast.LENGTH_SHORT).show()
                } finally {
                    isProcessing = false
                }
            }
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            selectedCrop?.let { onNavigateToCamera(it) }
        } else {
            Toast.makeText(context, "Camera permission denied", Toast.LENGTH_SHORT).show()
        }
    }

    Scaffold(
        containerColor = Color(0xFFF9FBF9),
        topBar = {
            TopAppBar(
                title = { Text("Select Crop", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        bottomBar = {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(start = 20.dp, end = 20.dp, bottom = 24.dp)
            ) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 10.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .padding(16.dp)
                            .fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedButton(
                            onClick = { galleryLauncher.launch("image/*") },
                            modifier = Modifier.weight(1f).height(56.dp),
                            enabled = selectedCrop != null,
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.5.dp, if (selectedCrop != null) AgroGreen else Color.LightGray)
                        ) {
                            Icon(Icons.Default.PhotoLibrary, null, tint = if (selectedCrop != null) AgroGreen else Color.Gray)
                            Spacer(Modifier.width(8.dp))
                            Text("Gallery", color = if (selectedCrop != null) AgroGreen else Color.Gray)
                        }

                        Button(
                            onClick = {
                                val permissionCheck = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA)
                                if (permissionCheck == PackageManager.PERMISSION_GRANTED) {
                                    selectedCrop?.let { onNavigateToCamera(it) }
                                } else {
                                    permissionLauncher.launch(Manifest.permission.CAMERA)
                                }
                            },
                            modifier = Modifier.weight(1.2f).height(56.dp),
                            enabled = selectedCrop != null,
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = AgroGreen,
                                disabledContainerColor = Color(0xFFE0E0E0)
                            )
                        ) {
                            Icon(Icons.Default.CameraAlt, null)
                            Spacer(Modifier.width(8.dp))
                            Text("Capture", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize()) {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 150.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 120.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(crops) { crop ->
                    CropCard(
                        name = crop,
                        isSelected = selectedCrop == crop,
                        onSelect = { selectedCrop = crop }
                    )
                }
            }

            if (isProcessing) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = AgroGreen)
                }
            }
        }
    }
}

@Composable
fun CropCard(name: String, isSelected: Boolean, onSelect: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(115.dp)
            .clickable { onSelect() },
        shape = RoundedCornerShape(20.dp),
        border = if (isSelected) BorderStroke(2.5.dp, AgroGreen) else BorderStroke(1.dp, Color(0xFFF0F0F0)),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(if (isSelected) 6.dp else 1.dp)
    ) {
        Box(modifier = Modifier.fillMaxSize().padding(8.dp)) {
            if (isSelected) {
                Icon(
                    Icons.Default.CheckCircle,
                    null,
                    Modifier.align(Alignment.TopEnd).size(22.dp),
                    tint = AgroGreen
                )
            }
            Column(
                modifier = Modifier.align(Alignment.Center),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(getEmojiForCrop(name), fontSize = 34.sp)
                Spacer(Modifier.height(4.dp))
                Text(name, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.DarkGray)
            }
        }
    }
}

fun getEmojiForCrop(name: String) = when(name) {
    "Tomato" -> "🍅"
    "Orange" -> "🍊"
    "Potato" -> "🥔"
    "Corn" -> "🌽"
    "Rice" -> "🌾"
    "Apple" -> "🍎"
    else -> "🌿"
}
