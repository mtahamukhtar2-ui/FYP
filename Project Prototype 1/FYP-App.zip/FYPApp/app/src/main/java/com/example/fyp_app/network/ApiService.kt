package com.example.fyp_app.network

import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Response
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part

interface ApiService {
    @Multipart
    // CORRECTED ENDPOINT: This now correctly points to the /predict endpoint
    @POST("predict")
    suspend fun uploadImage(
        @Part image: MultipartBody.Part,
        @Part("crop_type") cropType: RequestBody
    ): Response<DiagnosisResponse>
}
