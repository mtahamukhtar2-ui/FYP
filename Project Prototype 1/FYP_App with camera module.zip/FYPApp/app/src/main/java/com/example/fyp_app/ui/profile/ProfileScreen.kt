package com.example.fyp_app.ui.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.fyp_app.ui.theme.AgroGreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    name: String,
    email: String,
    onLogout: () -> Unit
) {
    Scaffold(
        containerColor = Color(0xFFF9FBF9),
        topBar = {
            TopAppBar(
                title = { Text("My Profile", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                ProfileHeader(name = name, email = email)
            }

            item {
                Text("Account Settings", style = MaterialTheme.typography.titleMedium, color = Color.Gray)
            }
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column {
                        ProfileActionTile(Icons.Default.History, "Diagnosis History") { }
                        HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), thickness = 0.5.dp)
                        ProfileActionTile(Icons.Default.Person, "Edit Profile") { }
                    }
                }
            }

            item {
                Text("Support", style = MaterialTheme.typography.titleMedium, color = Color.Gray)
            }
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column {
                        ProfileActionTile(Icons.Default.Help, "Help & FAQ") { }
                        HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), thickness = 0.5.dp)
                        ProfileActionTile(Icons.Default.Logout, "Sign Out", isDanger = true) { onLogout() }
                    }
                }
            }
        }
    }
}

@Composable
fun ProfileHeader(name: String, email: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(modifier = Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier.size(60.dp).clip(CircleShape).background(AgroGreen.copy(0.1f)),
                contentAlignment = Alignment.Center
            ) {
                Text(name.take(1), fontSize = 24.sp, fontWeight = FontWeight.Bold, color = AgroGreen)
            }
            Spacer(Modifier.width(16.dp))
            Column {
                Text(name, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(email, fontSize = 14.sp, color = Color.Gray)
            }
        }
    }
}

@Composable
fun ProfileActionTile(icon: ImageVector, title: String, isDanger: Boolean = false, onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().clickable { onClick() }.padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = if (isDanger) Color.Red else AgroGreen, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(16.dp))
        Text(title, modifier = Modifier.weight(1f), color = if (isDanger) Color.Red else Color.Black)
        Icon(Icons.Default.ChevronRight, null, tint = Color.LightGray)
    }
}