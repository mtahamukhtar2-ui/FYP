package com.example.fyp_app.network

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object RetrofitClient {

    // --- CORRECTED BASE URL ---
    // The base URL should only be the root of your server address.
    // Retrofit will add the "diagnose" endpoint from ApiService.kt to this.
    private const val BASE_URL = "https://usama1355-pdt-model-space.hf.space/"

    // Create a logger to see request and response details in Logcat (for debugging)
    private val loggingInterceptor = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BODY
    }

    // Create an OkHttp client with the logger AND LONGER TIMEOUTS
    private val okHttpClient = OkHttpClient.Builder()
        .addInterceptor(loggingInterceptor)
        .connectTimeout(60, TimeUnit.SECONDS) // 60-second timeout for connecting
        .readTimeout(60, TimeUnit.SECONDS)    // 60-second timeout for reading a response
        .writeTimeout(60, TimeUnit.SECONDS)   // 60-second timeout for writing a request
        .build()

    // Create the Retrofit instance using a lazy delegate
    private val retrofit by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient) // Use our custom OkHttp client
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    // Create the ApiService instance using a lazy delegate
    val instance: ApiService by lazy {
        retrofit.create(ApiService::class.java)
    }
}
