package com.example.fyp_app

import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CropFree
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.Chat
import androidx.compose.material.icons.outlined.CropFree
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.sp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.fyp_app.ui.auth.LoginScreen
import com.example.fyp_app.ui.auth.SignUpScreen
import com.example.fyp_app.ui.diagnose.DiagnoseScreen
import com.example.fyp_app.ui.home.HomeScreen
import com.example.fyp_app.ui.result.ResultScreen
import com.example.fyp_app.ui.theme.AgroGreen
import com.example.fyp_app.ui.theme.FYPAppTheme
import com.example.fyp_app.viewmodels.DiagnosisViewModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

class MainActivity : ComponentActivity() {

    // The 'by viewModels()' delegate correctly infers the type here.
    // The previous build errors were due to compiler/dependency issues.
    private val diagnosisViewModel: DiagnosisViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            FYPAppTheme {
                // Pass the single ViewModel instance to the navigation host
                AppNavigation(viewModel = diagnosisViewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppNavigation(viewModel: DiagnosisViewModel) {
    val navController = rememberNavController()
    val auth = FirebaseAuth.getInstance()
    val db = FirebaseFirestore.getInstance()
    val context = LocalContext.current

    var selectedItemIndex by remember { mutableIntStateOf(0) }
    val navigationRoutes = listOf("home_screen", "diagnose_screen", "assistant_screen", "profile_screen")

    // Determine the starting screen based on whether the user is logged in
    val startDestination = if (auth.currentUser != null) "home_screen" else "login_screen"

    // This listener updates the selected bottom nav item when the destination changes
    navController.addOnDestinationChangedListener { _, destination, _ ->
        val index = navigationRoutes.indexOf(destination.route)
        if (index >= 0) {
            selectedItemIndex = index
        }
    }

    Scaffold(
        bottomBar = {
            val navBackStackEntry by navController.currentBackStackEntryAsState()
            val currentRoute = navBackStackEntry?.destination?.route

            // Logic to show or hide the Bottom Navigation Bar
            val shouldShowBottomBar = currentRoute !in listOf("login_screen", "signup_screen") &&
                    currentRoute?.startsWith("result_screen") != true

            if (shouldShowBottomBar) {
                BottomNavBar(
                    selectedIndex = selectedItemIndex,
                    onItemSelected = { index ->
                        navController.navigate(navigationRoutes[index]) {
                            // Pop up to the start destination of the graph to
                            // avoid building up a large stack of destinations
                            popUpTo(navController.graph.findStartDestination().id) {
                                saveState = true
                            }
                            // Avoid multiple copies of the same destination when
                            // re-selecting the same item
                            launchSingleTop = true
                            // Restore state when re-selecting a previously selected item
                            restoreState = true
                        }
                    }
                )
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = startDestination,
            modifier = Modifier.padding(innerPadding)
        ) {
            // --- AUTH SCREENS ---
            composable("login_screen") {
                LoginScreen(
                    onLoginClick = { email, password ->
                        auth.signInWithEmailAndPassword(email.trim(), password.trim())
                            .addOnCompleteListener { task ->
                                if (task.isSuccessful) {
                                    navController.navigate("home_screen") { popUpTo("login_screen") { inclusive = true } }
                                } else {
                                    Toast.makeText(context, "Login Failed: ${task.exception?.message}", Toast.LENGTH_LONG).show()
                                }
                            }
                    },
                    onSignUpClick = { navController.navigate("signup_screen") }
                )
            }
            composable("signup_screen") {
                SignUpScreen(
                    onSignUpClick = { name, email, password ->
                        auth.createUserWithEmailAndPassword(email.trim(), password.trim())
                            .addOnCompleteListener { task ->
                                if (task.isSuccessful) {
                                    val userId = auth.currentUser?.uid
                                    if (userId != null) {
                                        db.collection("users").document(userId).set(hashMapOf("fullName" to name, "email" to email))
                                    }
                                    navController.navigate("home_screen") { popUpTo("signup_screen") { inclusive = true } }
                                } else {
                                    Toast.makeText(context, "Sign Up Failed: ${task.exception?.message}", Toast.LENGTH_LONG).show()
                                }
                            }
                    },
                    onLoginClick = { navController.popBackStack() }
                )
            }

            // --- MAIN APP SCREENS ---
            composable("home_screen") {
                HomeScreen(onNavigateToDiagnose = { navController.navigate("diagnose_screen") })
            }
            composable("diagnose_screen") {
                DiagnoseScreen(onImageSelected = { uri, cropType ->
                    // Encode the URI to make it safe to pass as a navigation argument
                    val encodedUri = URLEncoder.encode(uri.toString(), StandardCharsets.UTF_8.name())
                    navController.navigate("result_screen/$encodedUri/$cropType")
                })
            }
            composable("assistant_screen") {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Assistant Screen") }
            }
            composable("profile_screen") {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Profile Screen") }
            }

            // --- RESULT SCREEN ---
            composable(
                route = "result_screen/{imageUri}/{cropType}",
                arguments = listOf(
                    navArgument("imageUri") { type = NavType.StringType },
                    navArgument("cropType") { type = NavType.StringType }
                )
            ) { backStackEntry ->
                val imageUri = backStackEntry.arguments?.getString("imageUri") ?: ""
                val cropType = backStackEntry.arguments?.getString("cropType") ?: ""
                ResultScreen(
                    viewModel = viewModel,
                    imageUri = imageUri,
                    cropType = cropType,
                    onNavigateBack = { navController.popBackStack() }
                )
            }
        }
    }
}

@Composable
fun BottomNavBar(selectedIndex: Int, onItemSelected: (Int) -> Unit) {
    val items = listOf("Home", "Diagnose", "Assistant", "Profile")
    val selectedIcons = listOf(Icons.Filled.Home, Icons.Filled.CropFree, Icons.Filled.Chat, Icons.Filled.Person)
    val unselectedIcons = listOf(Icons.Outlined.Home, Icons.Outlined.CropFree, Icons.Outlined.Chat, Icons.Outlined.Person)

    NavigationBar(containerColor = Color.White, contentColor = AgroGreen) {
        items.forEachIndexed { index, item ->
            NavigationBarItem(
                selected = selectedIndex == index,
                onClick = { onItemSelected(index) },
                label = { Text(text = item, fontSize = 10.sp) },
                icon = {
                    Icon(
                        imageVector = if (selectedIndex == index) selectedIcons[index] else unselectedIcons[index],
                        contentDescription = item
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = AgroGreen,
                    selectedTextColor = AgroGreen,
                    indicatorColor = Color(0xFFE8F5E9), // Light green background for selected item
                    unselectedIconColor = Color.Gray,
                    unselectedTextColor = Color.Gray
                )
            )
        }
    }
}
