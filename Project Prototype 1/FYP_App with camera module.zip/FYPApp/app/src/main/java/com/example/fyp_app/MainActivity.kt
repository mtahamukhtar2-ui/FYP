package com.example.fyp_app

import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CropFree
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.Chat
import androidx.compose.material.icons.outlined.CropFree
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.sp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.example.fyp_app.ui.auth.LoginScreen
import com.example.fyp_app.ui.auth.SignUpScreen
import com.example.fyp_app.ui.camera.CameraScreen
import com.example.fyp_app.ui.diagnose.DiagnoseScreen
import com.example.fyp_app.utils.ImageProcessor
import com.example.fyp_app.ui.home.HomeScreen
import com.example.fyp_app.ui.profile.ProfileScreen // <--- LINKED
import com.example.fyp_app.ui.result.ResultScreen
import com.example.fyp_app.ui.theme.AgroGreen
import com.example.fyp_app.ui.theme.FYPAppTheme
import com.example.fyp_app.viewmodels.DiagnosisViewModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

class MainActivity : ComponentActivity() {
    private val diagnosisViewModel: DiagnosisViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            FYPAppTheme {
                AppNavigation(viewModel = diagnosisViewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppNavigation(viewModel: DiagnosisViewModel) {
    val navController = rememberNavController()
    val auth = FirebaseAuth.getInstance()
    val db = FirebaseFirestore.getInstance()
    val context = LocalContext.current

    // --- YOUR ORIGINAL PERSONALIZATION STATES ---
    var userName by remember { mutableStateOf("User") }
    var isNewUser by remember { mutableStateOf(false) }

    LaunchedEffect(auth.currentUser) {
        val user = auth.currentUser
        if (user != null) {
            isNewUser = user.metadata?.let {
                it.creationTimestamp == it.lastSignInTimestamp
            } ?: true

            val docRef = db.collection("users").document(user.uid)
            docRef.addSnapshotListener { snapshot, error ->
                if (error == null && snapshot != null && snapshot.exists()) {
                    val nameFromDb = snapshot.getString("fullName")
                    if (!nameFromDb.isNullOrEmpty()) userName = nameFromDb
                } else {
                    userName = user.displayName ?: "User"
                }
            }
        } else {
            userName = "User"
        }
    }

    var selectedItemIndex by remember { mutableIntStateOf(0) }
    val navigationRoutes = listOf("home_screen", "diagnose_screen", "assistant_screen", "profile_screen")
    val startDestination = if (auth.currentUser != null) "home_screen" else "login_screen"

    navController.addOnDestinationChangedListener { _, destination, _ ->
        val index = navigationRoutes.indexOf(destination.route)
        if (index >= 0) selectedItemIndex = index
    }

    Scaffold(
        bottomBar = {
            val navBackStackEntry by navController.currentBackStackEntryAsState()
            val currentRoute = navBackStackEntry?.destination?.route
            val shouldShowBottomBar = currentRoute !in listOf("login_screen", "signup_screen") &&
                    currentRoute?.startsWith("result_screen") != true

            if (shouldShowBottomBar) {
                BottomNavBar(
                    selectedIndex = selectedItemIndex,
                    onItemSelected = { index ->
                        navController.navigate(navigationRoutes[index]) {
                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                )
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = startDestination,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable("login_screen") {
                LoginScreen(
                    onLoginClick = { email, password ->
                        auth.signInWithEmailAndPassword(email.trim(), password.trim())
                            .addOnCompleteListener { task ->
                                if (task.isSuccessful) {
                                    navController.navigate("home_screen") {
                                        popUpTo("login_screen") { inclusive = true }
                                    }
                                } else {
                                    Toast.makeText(context, "Login Failed", Toast.LENGTH_SHORT).show()
                                }
                            }
                    },
                    onSignUpClick = { navController.navigate("signup_screen") }
                )
            }
            composable("signup_screen") {
                SignUpScreen(
                    onSignUpClick = { name, email, password ->
                        auth.createUserWithEmailAndPassword(email.trim(), password.trim())
                            .addOnCompleteListener { task ->
                                if (task.isSuccessful) {
                                    val userId = auth.currentUser?.uid
                                    if (userId != null) {
                                        db.collection("users").document(userId)
                                            .set(hashMapOf("fullName" to name, "email" to email))
                                            .addOnSuccessListener {
                                                navController.navigate("home_screen") {
                                                    popUpTo("signup_screen") { inclusive = true }
                                                }
                                            }
                                    }
                                }
                            }
                    },
                    onLoginClick = { navController.popBackStack() }
                )
            }

            composable("home_screen") {
                HomeScreen(
                    userName = userName,
                    isNewUser = isNewUser,
                    onNavigateToDiagnose = { navController.navigate("diagnose_screen") }
                )
            }

            composable("diagnose_screen") {
                DiagnoseScreen(
                    onImageSelected = { uri, cropType ->
                        val encodedUri = URLEncoder.encode(uri.toString(), StandardCharsets.UTF_8.name())
                        navController.navigate("result_screen/$encodedUri/$cropType")
                    },
                    onNavigateToCamera = { cropType ->
                        navController.navigate("camera_screen/$cropType")
                    }
                )
            }

            composable(
                route = "camera_screen/{cropType}",
                arguments = listOf(navArgument("cropType") { type = NavType.StringType })
            ) { backStackEntry ->
                val cropType = backStackEntry.arguments?.getString("cropType") ?: ""
                val scope = rememberCoroutineScope()
                var isProcessing by remember { mutableStateOf(false) }

                Box(modifier = Modifier.fillMaxSize()) {
                    CameraScreen(
                        cropType = cropType,
                        onImageCaptured = { uri ->
                            scope.launch {
                                isProcessing = true
                                try {
                                    val processedUri = ImageProcessor.processLeafImage(context, uri)
                                    val finalUri = processedUri ?: uri
                                    val encodedUri = URLEncoder.encode(finalUri.toString(), StandardCharsets.UTF_8.name())
                                    navController.navigate("result_screen/$encodedUri/$cropType") {
                                        popUpTo("camera_screen/$cropType") { inclusive = true }
                                    }
                                } finally {
                                    isProcessing = false
                                }
                            }
                        },
                        onBack = { navController.popBackStack() }
                    )

                    if (isProcessing) {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(color = com.example.fyp_app.ui.theme.AgroGreen)
                        }
                    }
                }
            }

            composable("assistant_screen") {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Assistant Screen Placeholder") }
            }

            // --- LINKED NEW PROFILE SCREEN ---
            composable("profile_screen") {// Get the email from the current Firebase user
                val userEmail = auth.currentUser?.email ?: "No Email"

                ProfileScreen(
                    name = userName,    // This uses the 'userName' state from your Firebase listener
                    email = userEmail,  // This uses the email from Firebase Auth
                    onLogout = {
                        auth.signOut()
                        navController.navigate("login_screen") {
                            popUpTo(0) { inclusive = true }
                        }
                    }
                )
            }

            composable(
                route = "result_screen/{imageUri}/{cropType}",
                arguments = listOf(
                    navArgument("imageUri") { type = NavType.StringType },
                    navArgument("cropType") { type = NavType.StringType }
                )
            ) { backStackEntry ->
                val imageUri = backStackEntry.arguments?.getString("imageUri") ?: ""
                val cropType = backStackEntry.arguments?.getString("cropType") ?: ""
                ResultScreen(
                    viewModel = viewModel,
                    imageUri = imageUri,
                    cropType = cropType,
                    onNavigateBack = { navController.popBackStack() }
                )
            }
        }
    }
}

@Composable
fun BottomNavBar(selectedIndex: Int, onItemSelected: (Int) -> Unit) {
    val items = listOf("Home", "Diagnose", "Assistant", "Profile")
    val selectedIcons = listOf(Icons.Filled.Home, Icons.Filled.CropFree, Icons.Filled.Chat, Icons.Filled.Person)
    val unselectedIcons = listOf(Icons.Outlined.Home, Icons.Outlined.CropFree, Icons.Outlined.Chat, Icons.Outlined.Person)

    NavigationBar(containerColor = Color.White, contentColor = AgroGreen) {
        items.forEachIndexed { index, item ->
            NavigationBarItem(
                selected = selectedIndex == index,
                onClick = { onItemSelected(index) },
                label = { Text(text = item, fontSize = 10.sp) },
                icon = {
                    Icon(
                        imageVector = if (selectedIndex == index) selectedIcons[index] else unselectedIcons[index],
                        contentDescription = item
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = AgroGreen,
                    selectedTextColor = AgroGreen,
                    indicatorColor = Color(0xFFE8F5E9),
                    unselectedIconColor = Color.Gray,
                    unselectedTextColor = Color.Gray
                )
            )
        }
    }
}