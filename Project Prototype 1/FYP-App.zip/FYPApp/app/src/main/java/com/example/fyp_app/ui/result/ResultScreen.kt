package com.example.fyp_app.ui.result

import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.rememberAsyncImagePainter
import com.example.fyp_app.ui.theme.AgroGreen
import com.example.fyp_app.viewmodels.DiagnosisViewModel
import com.example.fyp_app.viewmodels.UiState
import androidx.core.net.toUri
import com.example.fyp_app.network.DiagnosisResponse

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResultScreen(
    viewModel: DiagnosisViewModel,
    imageUri: String,
    cropType: String,
    onNavigateBack: () -> Unit
) {
    val decodedUri = imageUri.toUri()
    val context = LocalContext.current

    // Trigger the diagnosis when the screen is first composed
    LaunchedEffect(key1 = Unit) {
        viewModel.diagnoseImage(
            context = context,
            imageUri = decodedUri,
            cropType = cropType
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Diagnosis Result") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(contentDescription = "Back", imageVector = Icons.AutoMirrored.Filled.ArrowBack)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Color(0xFFF5F5F5))
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = rememberAsyncImagePainter(model = decodedUri),
                contentDescription = "Diagnosed Image",
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(16.dp)),
                contentScale = ContentScale.Crop
            )
            Spacer(modifier = Modifier.height(24.dp))

            // Display UI based on the ViewModel's state
            when (val state = viewModel.uiState) {
                is UiState.Loading -> LoadingState()
                is UiState.Success -> SuccessState(state.data)
                is UiState.Error -> ErrorState(state.message)

                // Added the UnsupportedCrop state handler here
                is UiState.UnsupportedCrop -> {
                    ErrorState(
                        message = "Diagnosis is currently only available for Orange crops. " +
                                "Support for other crops is coming soon!"
                    )
                }

                is UiState.Idle -> Unit // Do nothing initially
            }
        }
    }
}

@Composable
fun LoadingState() {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        CircularProgressIndicator(color = AgroGreen)
        Spacer(modifier = Modifier.height(16.dp))
        Text("Diagnosing...", fontSize = 18.sp, color = Color.Gray)
    }
}

@Composable
fun SuccessState(data: DiagnosisResponse) {
    Card(modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "RESULT",
                fontSize = 12.sp,
                color = Color.Gray,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(8.dp))
            Text(
                // Displays "Diagnosis Unknown" if prediction is null and replaces underscores with spaces
                text = (data.prediction ?: "Diagnosis Unknown").replace("_", " "),
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = AgroGreen,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Confidence:",
                    fontSize = 16.sp,
                    color = Color.Gray
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    // Confidence formatting logic
                    text = data.confidence?.let { String.format("%.2f%%", it * 100) } ?: "N/A",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Black
                )
            }
        }
    }
}

@Composable
fun ErrorState(message: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF0F0)) // Light red
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "Notice", // Changed from "An Error Occurred" to be more generic for Unsupported crops too
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Red
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = message,
                fontSize = 14.sp,
                textAlign = TextAlign.Center,
                color = Color.DarkGray
            )
        }
    }
}