package com.example.fyp_app.viewmodels

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.fyp_app.network.DiagnosisResponse
import com.example.fyp_app.network.RetrofitClient
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.io.FileOutputStream

// Represents the different states the UI can be in
sealed class UiState {
    object Idle : UiState()
    object Loading : UiState()
    data class Success(val data: DiagnosisResponse) : UiState()
    data class Error(val message: String) : UiState()
    // --- 1. NEW STATE ADDED ---
    // This state represents when a crop is selected that the model doesn't support.
    object UnsupportedCrop : UiState()
}

class DiagnosisViewModel : ViewModel() {

    var uiState: UiState by mutableStateOf(UiState.Idle)
        private set

    fun diagnoseImage(context: Context, imageUri: Uri, cropType: String) {
        // --- 2. LOGIC CHECK ADDED ---
        // First, check if the selected crop is "Orange".
        if (!cropType.equals("Orange", ignoreCase = true)) {
            // If it's any other crop, immediately set the state to UnsupportedCrop
            // and stop the function right here without calling the server.
            uiState = UiState.UnsupportedCrop
            Log.d("ViewModel", "Unsupported crop selected: $cropType. Halting diagnosis.")
            return
        }

        // The rest of the function will only run if the crop IS "Orange"
        viewModelScope.launch {
            uiState = UiState.Loading
            Log.d("ViewModel", "Starting diagnosis for crop: $cropType with image: $imageUri")

            try {
                // Get the file part from the URI
                val imageFilePart = uriToMultipartBodyPart(context, imageUri)

                if (imageFilePart == null) {
                    uiState = UiState.Error("Could not process the image file.")
                    return@launch
                }

                // Create a part for the crop type text
                val cropTypePart = cropType.toRequestBody("text/plain".toMediaTypeOrNull())

                // Make the API call
                val response = RetrofitClient.instance.uploadImage(
                    image = imageFilePart,
                    cropType = cropTypePart // Pass the crop type to the server
                )

                if (response.isSuccessful && response.body() != null) {
                    uiState = UiState.Success(response.body()!!)
                    Log.d("ViewModel", "Diagnosis successful: ${response.body()!!.prediction}")
                } else {
                    val errorBody = response.errorBody()?.string() ?: "Unknown error"
                    uiState = UiState.Error("API Error: ${response.code()} - $errorBody")
                    Log.e("ViewModel", "API Error: $errorBody")
                }

            } catch (e: Exception) {
                uiState = UiState.Error("Network Error: ${e.message}")
                Log.e("ViewModel", "Network exception", e)
            }
        }
    }

    // Helper function to convert a content URI (from gallery/camera) to a file part
    private fun uriToMultipartBodyPart(context: Context, uri: Uri): MultipartBody.Part? {
        return try {
            val file = File(context.cacheDir, "upload_temp_file")
            context.contentResolver.openInputStream(uri)?.use { inputStream ->
                FileOutputStream(file).use { outputStream ->
                    inputStream.copyTo(outputStream)
                }
            }
            val requestFile = file.asRequestBody("image/*".toMediaTypeOrNull())
            MultipartBody.Part.createFormData("file", file.name, requestFile)
        } catch (e: Exception) {
            Log.e("ViewModel", "Error converting URI to Part", e)
            null
        }
    }
}
