package com.example.fyp_app.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Newspaper
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.fyp_app.ui.theme.AgroGreen
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

// --- Data Models ---
data class QuickAction(
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val color: Long
)

// --- FIX 1: Add the 'onNavigateToDiagnose' parameter to the function definition ---
@Composable
fun HomeScreen(onNavigateToDiagnose: () -> Unit) {
    // 1. Variable to hold the name (Starts as "Farmer")
    var userName by remember { mutableStateOf("Farmer") }

    // 2. Fetch the name when screen opens
    LaunchedEffect(Unit) {
        val auth = FirebaseAuth.getInstance()
        val db = FirebaseFirestore.getInstance()
        val userId = auth.currentUser?.uid

        if (userId != null) {
            db.collection("users").document(userId).get()
                .addOnSuccessListener { document ->
                    if (document != null && document.exists()) {
                        val savedName = document.getString("fullName")
                        if (!savedName.isNullOrEmpty()) {
                            userName = savedName
                        }
                    }
                }
        }
    }

    // 3. Main Content Column (The Scaffold is now in MainActivity)
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F5F5)) // Light Gray Background
            .padding(20.dp)
    ) {
        HeaderSection(name = userName)

        Spacer(modifier = Modifier.height(24.dp))

        // --- Quick Actions ---
        Text(
            text = "QUICK ACTIONS",
            fontSize = 12.sp,
            color = Color.Gray,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        QuickActionsGrid()

        Spacer(modifier = Modifier.height(24.dp))

        // --- FIX 2: Pass the navigation function down to the CameraPromptSection ---
        CameraPromptSection(onStartCameraClick = onNavigateToDiagnose)
    }
}

@Composable
fun HeaderSection(name: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column {
            Text(
                text = "AgroGuard",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF2E7D32) // Green
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Hello, $name",
                fontSize = 24.sp,
                fontWeight = FontWeight.Medium,
                color = Color.Black
            )
        }
        Spacer(modifier = Modifier.weight(1f))

        // AI Badge
        Surface(
            color = Color(0xFFE8F5E9),
            shape = RoundedCornerShape(8.dp)
        ) {
            Text(
                text = "AI",
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                color = Color(0xFF2E7D32),
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
            )
        }
    }
}

@Composable
fun QuickActionsGrid() {
    val actions = listOf(
        QuickAction("AgroBot", "AI Assistant", Icons.Default.Chat, 0xFFE3F2FD),
        QuickAction("News", "Global Trends", Icons.Default.Newspaper, 0xFFE8F5E9)
    )

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        actions.forEach { action ->
            QuickActionCard(action = action, modifier = Modifier.weight(1f))
        }
    }
}

@Composable
fun QuickActionCard(action: QuickAction, modifier: Modifier = Modifier) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(action.color)),
        modifier = modifier.height(140.dp)
    ) {
        Column(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Icon(
                imageVector = action.icon,
                contentDescription = action.title,
                tint = Color.Black.copy(alpha = 0.6f),
                modifier = Modifier.size(32.dp)
            )
            Column {
                Text(
                    text = action.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = Color.Black
                )
                Text(
                    text = action.subtitle,
                    fontSize = 12.sp,
                    color = Color.Gray
                )
            }
        }
    }
}

// --- FIX 3: Update this composable to accept and use the click action ---
@Composable
fun CameraPromptSection(onStartCameraClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.White, RoundedCornerShape(12.dp))
            .clip(RoundedCornerShape(12.dp)) // Add clip for the ripple effect on click
            .clickable { onStartCameraClick() } // Make the whole row clickable
            .padding(16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "Diagnose a new crop?",
            fontSize = 14.sp,
            color = Color.Gray
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "Start Camera",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = AgroGreen
            )
            Icon(
                imageVector = Icons.Default.ArrowForward,
                contentDescription = null,
                tint = AgroGreen,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

// NOTE: The BottomNavBar composable has been moved to MainActivity.kt
// and should be deleted from this file if it's still here.

