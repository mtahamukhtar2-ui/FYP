package com.example.fyp_app.ui.diagnose

import android.Manifest
import android.net.Uri
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.fyp_app.R
import com.example.fyp_app.ui.theme.AgroGreen
import java.io.File
import java.util.UUID

data class Crop(val name: String, val apiName: String, val iconRes: Int)

@Composable
fun DiagnoseScreen(
    onImageSelected: (Uri, String) -> Unit // Callback to notify MainActivity
) {
    val context = LocalContext.current
    val crops = listOf(
        // The apiName should match what your server expects
        Crop("Tomato", "tomato", R.drawable.ic_tomato),
        Crop("Orange", "orange", R.drawable.ic_orange),
        Crop("Potato", "potato", R.drawable.ic_potato),
        Crop("Corn", "corn", R.drawable.ic_corn),
        Crop("Rice", "rice", R.drawable.ic_rice),
        Crop("Apple", "apple", R.drawable.ic_apple)
    )

    var selectedCropIndex by remember { mutableIntStateOf(-1) }
    var showImageSourceDialog by remember { mutableStateOf(false) }
    var tempImageUri by remember { mutableStateOf<Uri?>(null) }

    val handleImage = { uri: Uri? ->
        uri?.let {
            val selectedCrop = crops[selectedCropIndex]
            onImageSelected(it, selectedCrop.apiName)
        }
    }

    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        handleImage(uri)
    }

    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture(),
        onResult = { success -> if (success) handleImage(tempImageUri) }
    )
    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = { isGranted ->
            if (isGranted) {
                val file = File(context.cacheDir, "camera_${UUID.randomUUID()}.jpg")
                val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
                tempImageUri = uri
                cameraLauncher.launch(uri)
            } else {
                Toast.makeText(context, "Camera permission required.", Toast.LENGTH_SHORT).show()
            }
        }
    )
    val storagePermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) galleryLauncher.launch("image/*")
        else Toast.makeText(context, "Storage permission required.", Toast.LENGTH_SHORT).show()
    }

    // --- UI ---
    Scaffold { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Color(0xFFF5F5F5))
                .padding(horizontal = 20.dp)
        ) {
            Text(
                "Select Crop",
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 40.dp, bottom = 20.dp)
            )
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                itemsIndexed(crops) { index, crop ->
                    CropCard(
                        crop = crop,
                        isSelected = selectedCropIndex == index,
                        onCropSelected = { selectedCropIndex = index }
                    )
                }
            }
            Button(
                onClick = { if (selectedCropIndex != -1) showImageSourceDialog = true },
                modifier = Modifier.fillMaxWidth().padding(vertical = 20.dp).height(56.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AgroGreen),
                enabled = selectedCropIndex != -1
            ) {
                Text("Diagnose This Crop", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(8.dp))
                Icon(Icons.Default.ArrowForward, null)
            }
        }
    }

    if (showImageSourceDialog) {
        ImageSourceDialog(
            onDismiss = { showImageSourceDialog = false },
            onTakePicture = {
                showImageSourceDialog = false
                cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
            },
            onUploadFromDevice = {
                showImageSourceDialog = false
                if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.S_V2) {
                    storagePermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
                } else {
                    galleryLauncher.launch("image/*")
                }
            }
        )
    }
}


@Composable
fun CropCard(crop: Crop, isSelected: Boolean, onCropSelected: () -> Unit) {
    val borderColor = if (isSelected) AgroGreen else Color.LightGray
    Card(
        modifier = Modifier
            .aspectRatio(1f)
            .border(2.dp, borderColor, RoundedCornerShape(16.dp))
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onCropSelected),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Image(
                painter = painterResource(id = crop.iconRes),
                contentDescription = crop.name,
                modifier = Modifier.weight(1f).fillMaxSize(0.6f),
                contentScale = ContentScale.Fit
            )
            Spacer(Modifier.height(12.dp))
            Text(crop.name, fontWeight = FontWeight.Medium, fontSize = 16.sp)
        }
    }
}

@Composable
fun ImageSourceDialog(
    onDismiss: () -> Unit, onTakePicture: () -> Unit, onUploadFromDevice: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Choose Image Source", fontWeight = FontWeight.Bold) },
        text = { Text("How would you like to provide an image of the crop?") },
        confirmButton = { TextButton(onClick = onTakePicture) { Text("Take Picture", color = AgroGreen) } },
        dismissButton = { TextButton(onClick = onUploadFromDevice) { Text("Upload from Device", color = AgroGreen) } }
    )
}
