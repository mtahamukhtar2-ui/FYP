package com.example.fyp_app.ui.result

import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.net.toUri
import coil.compose.rememberAsyncImagePainter
import com.example.fyp_app.ui.theme.AgroGreen
import com.example.fyp_app.viewmodels.DiagnosisViewModel
import com.example.fyp_app.viewmodels.UiState

val OffWhite = Color(0xFFF9FBF9)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResultScreen(
    viewModel: DiagnosisViewModel,
    imageUri: String,
    cropType: String,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val uiState = viewModel.uiState
    val configuration = LocalConfiguration.current
    val screenHeight = configuration.screenHeightDp.dp

    LaunchedEffect(Unit) {
        val decodedUriString = Uri.decode(imageUri)
        val uri = decodedUriString.toUri()
        viewModel.diagnoseImage(context, uri, cropType)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Diagnosis Result", fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        containerColor = OffWhite
    ) { padding ->
        // BoxWithConstraints makes the UI aware of its parent size
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            val maxWidth = maxWidth
            val maxHeight = maxHeight

            // Avoid division by zero or NaN if constraints are zero
            val horizontalPadding = if (maxWidth.value > 0) (maxWidth.value * 0.05f).dp else 16.dp
            val imageHeightMax = if (maxHeight.value > 0) maxHeight * 0.45f else 300.dp
            val spacerHeight = if (maxHeight.value > 0) (maxHeight.value * 0.03f).dp else 16.dp

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = horizontalPadding),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(modifier = Modifier.height(16.dp))

                // RESPONSIVE IMAGE CARD
                Card(
                    shape = RoundedCornerShape(24.dp),
                    elevation = CardDefaults.cardElevation(6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 250.dp, max = imageHeightMax)
                ) {
                    Image(
                        painter = rememberAsyncImagePainter(Uri.decode(imageUri).toUri()),
                        contentDescription = "Scanned Image",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }

                Spacer(modifier = Modifier.height(spacerHeight))

                // DYNAMIC CONTENT AREA
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 24.dp),
                    contentAlignment = Alignment.TopCenter
                ) {
                    when (uiState) {
                        is UiState.Loading -> {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(top = 32.dp)
                            ) {
                                CircularProgressIndicator(color = AgroGreen, strokeWidth = 4.dp)
                                Spacer(Modifier.height(16.dp))
                                Text("Analyzing Image...", color = Color.Gray, fontSize = 16.sp)
                            }
                        }

                        is UiState.Success -> {
                            ResultCard(
                                title = uiState.data.prediction?.replace("_", " ") ?: "Unknown",
                                confidence = uiState.data.confidence ?: 0.0,
                                cropType = cropType
                            )
                        }

                        is UiState.UnsupportedCrop -> {
                            InfoCard(
                                title = "Crop Not Supported",
                                message = "Currently, our AI is trained for Orange crops. Support for $cropType is coming soon!",
                                containerColor = Color(0xFFFFF3E0),
                                contentColor = Color(0xFFE65100)
                            )
                        }

                        is UiState.Error -> {
                            InfoCard(
                                title = "Analysis Failed",
                                message = uiState.message,
                                containerColor = Color(0xFFFFF0F0),
                                contentColor = Color.Red
                            )
                        }
                        else -> {}
                    }
                }
            }
        }
    }
}

@Composable
fun ResultCard(title: String, confidence: Double, cropType: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(24.dp),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Surface(
                color = AgroGreen.copy(alpha = 0.1f),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    text = cropType.uppercase(),
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                    fontSize = 12.sp,
                    color = AgroGreen,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = title.uppercase(),
                fontSize = 24.sp,
                fontWeight = FontWeight.ExtraBold,
                textAlign = TextAlign.Center,
                lineHeight = 30.sp,
                color = Color(0xFF1A1A1A)
            )

            HorizontalDivider(
                modifier = Modifier.padding(vertical = 20.dp),
                thickness = 1.dp,
                color = Color.LightGray.copy(alpha = 0.5f)
            )

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                Text("Confidence Score", color = Color.Gray, fontSize = 14.sp)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = String.format("%.1f%%", confidence * 100),
                    fontWeight = FontWeight.ExtraBold,
                    color = if (confidence > 0.7) AgroGreen else Color.DarkGray,
                    fontSize = 20.sp
                )
            }
        }
    }
}

@Composable
fun InfoCard(title: String, message: String, containerColor: Color, contentColor: Color) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(Modifier.padding(24.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, fontWeight = FontWeight.Bold, color = contentColor, fontSize = 18.sp)
            }
            Spacer(Modifier.height(12.dp))
            Text(
                text = message,
                color = Color.DarkGray.copy(alpha = 0.8f),
                fontSize = 15.sp,
                lineHeight = 22.sp
            )
        }
    }
}