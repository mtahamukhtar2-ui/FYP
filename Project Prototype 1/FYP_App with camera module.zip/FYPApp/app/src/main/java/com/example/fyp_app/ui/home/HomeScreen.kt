package com.example.fyp_app.ui.home

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.location.Location
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.fyp_app.ui.theme.AgroGreen
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource

val OffWhite = Color(0xFFF9FBF9)

@SuppressLint("MissingPermission")
@Composable
fun HomeScreen(
    userName: String,
    isNewUser: Boolean,
    onNavigateToDiagnose: () -> Unit,
    weatherViewModel: WeatherViewModel = viewModel()
) {
    val context = LocalContext.current
    val fusedLocationClient = remember { LocationServices.getFusedLocationProviderClient(context) }

    // Logic to get location and then fetch weather
    val fetchLocationAndWeather = {
        fusedLocationClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, CancellationTokenSource().token)
            .addOnSuccessListener { location: Location? ->
                if (location != null) {
                    weatherViewModel.fetchWeather(location.latitude, location.longitude)
                } else {
                    // Fallback to last location if current is null
                    fusedLocationClient.lastLocation.addOnSuccessListener { lastLoc ->
                        lastLoc?.let { weatherViewModel.fetchWeather(it.latitude, it.longitude) }
                    }
                }
            }
    }

    val locationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        if (permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        ) {
            fetchLocationAndWeather()
        }
    }

    LaunchedEffect(Unit) {
        val fineLoc = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION)
        val coarseLoc = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION)

        if (fineLoc == PackageManager.PERMISSION_GRANTED || coarseLoc == PackageManager.PERMISSION_GRANTED) {
            fetchLocationAndWeather()
        } else {
            locationPermissionLauncher.launch(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
            )
        }
    }

    Scaffold(
        containerColor = OffWhite
    ) { padding ->
        BoxWithConstraints(modifier = Modifier.fillMaxSize().padding(padding)) {
            val maxWidth = maxWidth
            val horizontalPadding = (maxWidth.value * 0.05f).dp

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = horizontalPadding, vertical = 24.dp)
            ) {
                item {
                    HeaderSection(userName, isNewUser)
                    Spacer(modifier = Modifier.height(24.dp))
                }

                item {
                    WeatherBanner(
                        temp = weatherViewModel.temp,
                        condition = weatherViewModel.condition,
                        city = weatherViewModel.city
                    )
                    Spacer(modifier = Modifier.height(28.dp))
                }

                item {
                    Text(
                        text = "QUICK ACTIONS",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.Gray,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    ResponsiveActionGrid(onNavigateToDiagnose, maxWidth)
                }
            }
        }
    }
}

@Composable
fun HeaderSection(userName: String, isNewUser: Boolean) {
    Column {
        Text(text = "AGROGUARD", color = AgroGreen, fontSize = 12.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = buildAnnotatedString {
                append("Hello ")
                withStyle(style = SpanStyle(color = Color(0xFF1A1A1A), fontWeight = FontWeight.Bold)) {
                    append("$userName!")
                }
            },
            fontSize = 26.sp, fontWeight = FontWeight.Normal, color = Color.DarkGray
        )
        Text(
            text = if (isNewUser) "Welcome to AgroGuard" else "Welcome back to AgroGuard",
            fontSize = 15.sp, color = Color.Gray, fontWeight = FontWeight.Medium
        )
    }
}

@Composable
fun WeatherBanner(temp: String, condition: String, city: String) {
    val (bgColor, icon) = when {
        condition.contains("Rain", true) -> Color(0xFF4FC3F7) to Icons.Default.Cloud
        condition.contains("Cloud", true) -> Color(0xFF90A4AE) to Icons.Default.Cloud
        else -> AgroGreen to Icons.Default.WbSunny
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = bgColor),
        elevation = CardDefaults.cardElevation(4.dp)
    ) {
        Row(modifier = Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text("$temp · $condition", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(
                    text = if(city.isNotEmpty()) "Location: $city" else "Checking local weather...",
                    color = Color.White.copy(alpha = 0.8f),
                    fontSize = 13.sp
                )
            }
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (condition.contains("Clear", true) || condition.contains("Sunny", true)) Color(0xFFFFD600) else Color.White,
                modifier = Modifier.size(44.dp)
            )
        }
    }
}

@Composable
fun ResponsiveActionGrid(onScanClick: () -> Unit, maxWidth: androidx.compose.ui.unit.Dp) {
    val cardHeight = if (maxWidth > 600.dp) 140.dp else 115.dp

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            // This is the card that triggers the Camera Module
            ActionCard(
                title = "Scan Crop",
                subtitle = "Detect disease",
                icon = Icons.Outlined.CameraAlt,
                iconBg = Color(0xFFE8F5E9),
                modifier = Modifier
                    .weight(1f)
                    .height(cardHeight)
                    .clickable { onScanClick() } // <--- This triggers the navigation
            )

            ActionCard("AgroBot", "AI assistant", Icons.Outlined.ChatBubbleOutline, Color(0xFFE3F2FD), Modifier.weight(1f).height(cardHeight))
        }
        // ... rest of your rows
    }
}

@Composable
fun ActionCard(title: String, subtitle: String, icon: ImageVector, iconBg: Color, modifier: Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Box(Modifier.size(36.dp).background(iconBg, RoundedCornerShape(8.dp)), contentAlignment = Alignment.Center) {
                Icon(icon, null, Modifier.size(20.dp), tint = Color.DarkGray)
            }
            Spacer(Modifier.weight(1f))
            Text(title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text(subtitle, color = Color.Gray, fontSize = 11.sp)
        }
    }
}