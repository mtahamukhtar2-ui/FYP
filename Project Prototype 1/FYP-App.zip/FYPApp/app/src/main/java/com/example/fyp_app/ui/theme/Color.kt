package com.example.fyp_app.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)
// Add this to your existing colors
val AgroGreen = Color(0xFF2E7D32) // Adjust this hex code to match your image exactly if needed
val LightBackground = Color(0xFFF5F5F5) // A slight off-white for the background
