package com.example.fyp_app.network

import com.google.gson.annotations.SerializedName

/**
 * This data class is now robust.
 * 1. @SerializedName ensures the JSON key "prediction" is mapped to the `prediction` property.
 * 2. Making the properties nullable (String?, Double?) prevents crashes if the server
 *    response is missing a field for any reason.
 */
data class DiagnosisResponse(
    @SerializedName("class")
    val prediction: String?, // Now nullable

    @SerializedName("confidence")
    val confidence: Double?  // Now nullable
)
